#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'phongphamhong'

# !/usr/bin/python
#
# Copyright 3/18/19 Phong Pham Hong <phongbro1805@gmail.com>
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from conf import CONFIG
import pymongo
import pymongo
import os
from os import listdir
from os.path import isfile, join
import csv
import json
import logging.handlers
import time

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("ETL")
logger.setLevel(logging.INFO)
logging.Formatter.converter = time.gmtime

mongodb_client = pymongo.MongoClient(CONFIG['mongodb_uri'])
collection = mongodb_client['demo']['test']


def process_files():
    path = CONFIG['data_folder']
    onlyfiles = [f for f in listdir(path) if isfile(join(path, f)) and f.find('_done') < 0]
    for file in onlyfiles:
        extension = os.path.splitext(file)[1]
        if (extension.find('.json') >= 0):
            read_data_json(file)
        elif (extension.find('.csv') >= 0):
            read_data_csv(file)


def lock_job():
    pass


def get_full_file_path(file):
    return CONFIG['data_folder'] + file


def rename_file_name(file):
    try:
        os.rename(file, file + '_done')
    except BaseException as e:
        print(e)


def read_data_csv(file):
    logger.info(msg='Open file %s' % file)
    file = get_full_file_path(file)
    with open(file) as csv_file:
        csv_reader = csv.DictReader(csv_file, delimiter=',')
        line_count = 0
        data = []
        for row in csv_reader:
            item = dict(row)
            data.append(item)
            if len(data) >= 500:
                collection.insert(data)
                data = []
        if len(data) > 0:
            collection.insert(data)
            data = []
    rename_file_name(file)


def read_data_json(file):
    file = get_full_file_path(file)
    logger.info(msg='Open file %s' % file)
    with open(file) as f:
        lines = f.readlines()
        data = []
        for line in lines:
            try:
                item = json.loads(line)
                data.append(item)
                if len(data) >= 500:
                    collection.insert(data)
                    data = []
            except BaseException as e:
                pass
        if len(data) > 0:
            collection.insert(data)
            data = []
    rename_file_name(file)


def process():
    process_files()


if __name__ == '__main__':
    process()
